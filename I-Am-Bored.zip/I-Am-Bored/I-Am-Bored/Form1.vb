﻿Public Class Form1
    Dim ButtonClickCount As Integer = 0
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        System.Diagnostics.Process.Start("http://patreon.com/SlipSerum")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ButtonClickCount += 1
        Label1.Text = ButtonClickCount + " you have donate. "
    End Sub
End Class
